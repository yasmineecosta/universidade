package associacao;

public class TestePagamento {

    public static void main(String[] args) throws AssociacaoJaExistente, ValorInvalido, AssociacaoNaoExistente, TaxaJaExistente, AssociadoJaExistente, AssociadoNaoExistente, AssociadoJaRemido, TaxaNaoExistente {
    
    MinhaAssociacao SAS = new MinhaAssociacao();    
    Associacao a1 = new Associacao(1, "Associacao dos Programadores");
    SAS.adicionar(a1);
    Associado as1 = new Associado(1, "Joao", "1234-5678", 1980, 2010);
    Taxa t1 = new Taxa("Taxa 1", 2010, 1200, 12, true);
    SAS.adicionar(1, t1);
    SAS.adicionar(1, as1);
    double valor = 100.00;
    long data = 2022;
    long data2 = 2023;
    long data3 = 2019;
    SAS.registrarPagamento(1, "Taxa 1" , 2010, 1, data, valor);
    System.out.println("Valor pago: " + SAS.somarPagamentoDeAssociado(1, 1, "Taxa 1", 2010, data2, data3));

    }
}