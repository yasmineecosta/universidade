package associacao;

public class AssociadoJaRemido extends Exception {
    public AssociadoJaRemido(String msg) {
        super(msg);
    }
}
