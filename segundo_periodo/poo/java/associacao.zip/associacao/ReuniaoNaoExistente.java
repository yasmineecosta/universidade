package associacao;

public class ReuniaoNaoExistente extends Exception{
    public ReuniaoNaoExistente(String msg){
        super(msg);
    }
}
