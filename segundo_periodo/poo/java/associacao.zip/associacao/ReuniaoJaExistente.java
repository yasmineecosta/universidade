package associacao;

public class ReuniaoJaExistente extends Exception {
    public ReuniaoJaExistente(String msg) {
        super(msg);
    }
}
