package associacao;

public class TaxaJaExistente extends Exception {
    public TaxaJaExistente(String msg) {
        super(msg);
    }
}
