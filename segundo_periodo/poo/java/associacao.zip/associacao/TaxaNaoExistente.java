package associacao;

public class TaxaNaoExistente extends Exception{
    public TaxaNaoExistente(String msg){
        super(msg);
    }
}
