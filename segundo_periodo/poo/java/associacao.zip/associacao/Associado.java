package associacao;

import java.util.ArrayList;

public class Associado {
    //Um associado tem como atributos numero positivo (int), nome (String), telefone (String), nascimento (long), dataAssociacao (long)
   private int numero;
   private String nome;
   private String telefone;
   private long nascimento;
   private long dataAssociacao;
   ArrayList<Pagamento> pagamentos = new ArrayList<Pagamento>();

  public Associado(int numero, String nome, String telefone, long nascimento, long dataAssociacao) {
        this.numero = numero;
        this.nome = nome;
        this.telefone = telefone;
        this.nascimento = nascimento;
        this.dataAssociacao = dataAssociacao;
          
    }

    public void setPagamentos(ArrayList<Taxa> taxas){
          for(Taxa taxa : taxas){
               Pagamento pagamento = new Pagamento(taxa);
               pagamentos.add(pagamento);
          }
    }


    public int getNumero() {
         return numero;
    }   

    public String getNome() {
         return nome;
    }

    public String getTelefone() {
         return telefone;
    }

    public long getNascimento() {
         return nascimento;
    }

    public long getDataAssociacao() {
         return dataAssociacao;
    }

     public ArrayList<Pagamento> getPagamentos() {
          return pagamentos;
     }

     public double getPagamento(Taxa taxa){
          for(Pagamento pagamento : pagamentos){
               if(pagamento.getTaxa().equals(taxa)){
                    return pagamento.getValorPago();
               }
          }
          return 0;
     }

     public boolean verificaTaxa(Taxa taxa){
          for(Pagamento pagamento : pagamentos){
               if(pagamento.getTaxa().equals(taxa)){
                    System.out.println("Taxa ja registrada");
                    return true;
               }
          }
          return false;
     }
     
}
