package associacao;

import java.util.ArrayList;

public class MinhaAssociacao implements InterfaceAssociacao {

    ArrayList<Associacao> associacoes = new ArrayList<Associacao>();

    @Override
    public double calcularFrequencia(int numAssociado, int numAssociacao, long inicio, long fim) throws AssociadoNaoExistente, ReuniaoNaoExistente, AssociacaoNaoExistente {
        
        Associacao atemp = pesquisarAssociacao(numAssociacao);
        if(atemp == null)
            throw new AssociacaoNaoExistente("Associação não existente");

        ArrayList<Reuniao> reunioesNoPeriodo = atemp.getReuniosNoPeriodo(inicio, fim);    
        if(reunioesNoPeriodo.size() == 0)
            throw new ReuniaoNaoExistente("Reunião não existente");

        Associado associado = atemp.pesquisaAssociado(numAssociado);
        if(associado == null)
            throw new AssociadoNaoExistente("Associado não existente");

        double frequência = 0;    

        for(int i = 0; i<reunioesNoPeriodo.size(); i++){
            for(int j = 0; j<reunioesNoPeriodo.get(i).getParticipantes().size(); j++){
                if(reunioesNoPeriodo.get(i).getParticipantes().get(j).getNumero() == associado.getNumero())
                    frequência++;
            }
        }

        return frequência/reunioesNoPeriodo.size();

    }

    @Override
    public void registrarFrequencia(int codigoAssociado, int numAssociacao, long dataReuniao) throws AssociadoNaoExistente, ReuniaoNaoExistente, AssociacaoNaoExistente, FrequenciaJaRegistrada, FrequenciaIncompativel {
        
        Associacao atemp = pesquisarAssociacao(numAssociacao);
        if(atemp == null)
            throw new AssociacaoNaoExistente("Associação não existente");

        Associado associado = atemp.pesquisaAssociado(codigoAssociado);
        if(associado == null)
            throw new AssociadoNaoExistente("Associado não existente");

        Reuniao reuniao = atemp.pesquisarReuniao(dataReuniao);
        if(reuniao == null)
            throw new FrequenciaIncompativel("Reunião não existente");

        if(associado.getDataAssociacao()>(reuniao.getData()))
            throw new FrequenciaIncompativel("Frequência incompatível");

        for(int i = 0; i < reuniao.getParticipantes().size(); i++){
            if(reuniao.getParticipantes().get(i).getNumero() == associado.getNumero())
                throw new FrequenciaJaRegistrada("Frequência já registrada");
        }

        reuniao.getParticipantes().add(associado);

    }

    @Override
    public void registrarPagamento(int numAssociacao, String taxa, int vigencia, int numAssociado, long data, double valor) throws AssociacaoNaoExistente, AssociadoNaoExistente, AssociadoJaRemido, TaxaNaoExistente, ValorInvalido {
       
        Associacao atemp = pesquisarAssociacao(numAssociacao);
        if(atemp == null)
            throw new AssociacaoNaoExistente("Associação não existente");

        Associado associado = atemp.pesquisaAssociado(numAssociado);
        if(associado == null)
            throw new AssociadoNaoExistente("Associado não existente");

        Pagamento pagamento = null;

        for(int i = 0; i<associado.getPagamentos().size(); i++){
            if(associado.getPagamentos().get(i).getTaxa().getNome() == taxa && associado.getPagamentos().get(i).getTaxa().getVigencia() == vigencia)
                pagamento = associado.getPagamentos().get(i);
        }

        Taxa taxatemp = atemp.pesquisarTaxa(taxa,vigencia);
        if(taxatemp == null)
            throw new TaxaNaoExistente("Taxa não existente");

        if(associado instanceof AssociadoRemido && taxatemp.isAdmnistrativa() && ((AssociadoRemido)associado).getDataRemissao()<=(data))
            throw new AssociadoJaRemido("Associado já remido");

        double valorParcela = taxatemp.getValorAno()/taxatemp.getParcelas();
        double valorRestante = taxatemp.getValorAno() - pagamento.getValorPago();

        if((valor < valorParcela && valorRestante > valorParcela)  || valor > taxatemp.getValorAno())
            throw new ValorInvalido("Valor inválido");

        pagamento.pagarTaxa(valor);

    }

    @Override
    public double somarPagamentoDeAssociado(int numAssociacao, int numAssociado, String nomeTaxa, int vigencia, long inicio, long fim) throws AssociacaoNaoExistente, AssociadoNaoExistente, TaxaNaoExistente {
        
        double pagamento = 0;

        Associacao atemp = pesquisarAssociacao(numAssociacao);

        if(atemp == null)
            throw new AssociacaoNaoExistente("Associação não existente");

        Associado associado = atemp.pesquisaAssociado(numAssociado);
        if(associado == null)
            throw new AssociadoNaoExistente("Associado não existente");

        Taxa taxatemp = atemp.pesquisarTaxa(nomeTaxa,vigencia);
        if(taxatemp == null)
            throw new TaxaNaoExistente("Taxa não existente");

            pagamento = associado.getPagamento(taxatemp);

        return pagamento;
    }
    
    @Override
    public double calcularTotalDeTaxas(int numAssociacao, int vigencia) throws AssociacaoNaoExistente, TaxaNaoExistente {
        
        Associacao atemp = pesquisarAssociacao(numAssociacao);
        if(atemp == null)
            throw new AssociacaoNaoExistente("Associação não existente");

        double total = 0;

        for(int i = 0; i<atemp.getTaxas().size(); i++){
            if(atemp.getTaxas().get(i).getVigencia() == vigencia)
                total += atemp.getTaxas().get(i).getValorAno();
        }

        if(total == 0)
            throw new TaxaNaoExistente("Taxa não existente");

        return total;

    }

    @Override
    public void adicionar(Associacao a) throws AssociacaoJaExistente, ValorInvalido {
        
        if(a.getNome() == null || a.getNome().isBlank() || a.getNome().isEmpty())
            throw new ValorInvalido("Nome da associação não pode ser vazio");
        if(a.getNumero() <= 0)
            throw new ValorInvalido("Número da associação não pode ser menor ou igual a zero");

        for(int i = 0; i<associacoes.size(); i++){
            if(associacoes.get(i).getNumero() == a.getNumero())
                throw new AssociacaoJaExistente("Associação já existente");
        }

         associacoes.add(a);   

    }

    @Override
    public void adicionar(int associacao, Associado a) throws AssociacaoNaoExistente, AssociadoJaExistente, ValorInvalido {

        Associacao atemp = pesquisarAssociacao(associacao);

        if(a.getNome().isBlank() || a.getNome().isEmpty() || a.getNome() == null)
            throw new ValorInvalido("Nome do associado não pode ser vazio");

        if(a.getNumero() <= 0)
            throw new ValorInvalido("Número do associado não pode ser menor ou igual a zero");

        if(a.getTelefone().isBlank() || a.getTelefone().isEmpty() || a.getTelefone() == null)
            throw new ValorInvalido("Telefone do associado não pode ser vazio");

        if(a.getDataAssociacao()<=0)
            throw new ValorInvalido("Data de associação do associado não pode ser vazio");

        if(a.getNascimento()<=0)
            throw new ValorInvalido("Data de nascimento do associado não pode ser vazio");

        for(int i = 0; i<associacoes.size(); i++){
            if(associacoes.get(i).getNumero() == associacao)
                atemp = associacoes.get(i);
        }

        if(atemp == null)
            throw new AssociacaoNaoExistente("Associação não existente");

        for(int i = 0; i<atemp.getAssociados().size(); i++){
            if(atemp.getAssociados().get(i).getNumero() == a.getNumero())
                throw new AssociadoJaExistente("Associado já existente");
        }

        a.setPagamentos(atemp.getTaxas());
        atemp.getAssociados().add(a);
    }

    @Override
    public void adicionar(int associacao, Reuniao r) throws AssociacaoNaoExistente, ReuniaoJaExistente, ValorInvalido {
        
        Associacao atemp = pesquisarAssociacao(associacao);

        if(r.getAta().isBlank() || r.getAta().isEmpty() || r.getAta() == null)
            throw new ValorInvalido("Ata da reunião não pode ser vazio");

        if(r.getData()<=0)
            throw new ValorInvalido("Data da reunião não pode ser vazio");

        //if(r.getParticipantes().size() == 0)
        //    throw new ValorInvalido("Reunião deve ter pelo menos um participante");

        for(int i = 0; i<associacoes.size(); i++){
            if(associacoes.get(i).getNumero() == associacao)
                atemp = associacoes.get(i);
        }
        
        if(atemp == null)
            throw new AssociacaoNaoExistente("Associação não existente");
        
        for(int i = 0; i<atemp.getReunioes().size(); i++){
            if(atemp.getReunioes().get(i).getData()==(r.getData()))
                throw new ReuniaoJaExistente("Reunião já existente");
        }
        
        atemp.getReunioes().add(r);

    }

    @Override
    public void adicionar(int associacao, Taxa t) throws AssociacaoNaoExistente, TaxaJaExistente, ValorInvalido {
        
        Associacao atemp = pesquisarAssociacao(associacao);

        if(t.getNome().isBlank() || t.getNome().isEmpty() || t.getNome() == null)
            throw new ValorInvalido("Nome da taxa não pode ser vazio");

        if(t.getParcelas() <= 0)
            throw new ValorInvalido("Número de parcelas da taxa não pode ser menor ou igual a zero");
            
        if(t.getValorAno() <= 0)
            throw new ValorInvalido("Valor da taxa não pode ser menor ou igual a zero");

        if(t.getVigencia() <= 0)
            throw new ValorInvalido("Vigência da taxa não pode ser menor ou igual a zero");

        for(int i = 0; i<associacoes.size(); i++){
            if(associacoes.get(i).getNumero() == associacao)
                atemp = associacoes.get(i);
        }

        if(atemp == null)
            throw new AssociacaoNaoExistente("Associação não existente");

        for(int i =0;i<atemp.getTaxas().size();i++){
            if(atemp.getTaxas().get(i).getNome().equals(t.getNome()) && atemp.getTaxas().get(i).getVigencia() == t.getVigencia())
                throw new TaxaJaExistente("Taxa já existente");
        }

        atemp.getTaxas().add(t);

        for(int i=0;i<atemp.getAssociados().size();i++){
            if(atemp.getAssociados().get(i).verificaTaxa(t) == false){
            atemp.getAssociados().get(i).getPagamentos().add(new Pagamento(t));
            }
        }
            

    }
    
    public Associacao pesquisarAssociacao(int numero){
        
        Associacao atemp = null;
        
        for(int i = 0; i<associacoes.size(); i++){
            if(associacoes.get(i).getNumero() == numero)
                atemp = associacoes.get(i);
        }
        return atemp;
        
    }
}
