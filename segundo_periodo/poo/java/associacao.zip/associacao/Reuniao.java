package associacao;

import java.util.ArrayList;

public class Reuniao {
    
    //cada reunião com indicação dos participantes da reunião.
    //Durante uma reunião é registrada a frequência dos participantes, bem como é construída uma ata. A ata é apenas um texto relatando os acontecimentos naquela data.
    
    private long data;
    private String ata;
    private ArrayList<Associado> participantes = new ArrayList<Associado>();

    public Reuniao(long data, String ata){
        this.data = data;
        this.ata = ata;
    }

    public long getData() {
        return data;
    }       

    public String getAta() {
        return ata;
    }

    public ArrayList<Associado> getParticipantes() {
        return participantes;
    }
    

}
