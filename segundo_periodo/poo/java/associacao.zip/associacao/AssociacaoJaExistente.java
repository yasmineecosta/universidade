package associacao;

public class AssociacaoJaExistente extends Exception {
    public AssociacaoJaExistente(String msg) {
        super(msg);
    }
}
