package associacao;

public class AssociadoRemido extends Associado {

    long dataRemissao;

    public AssociadoRemido(int numero, String nome, String telefone, long dataAssociacao, long nascimento, long dataRemissao) {
        super(numero, nome, telefone, nascimento, dataAssociacao);
        this.dataRemissao = dataRemissao;
    }

    public long getDataRemissao() {
        return dataRemissao;
    }
    
}
