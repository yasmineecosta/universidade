package associacao;

public class FrequenciaIncompativel extends Exception {
    public FrequenciaIncompativel(String msg) {
        super(msg);
    }
}
