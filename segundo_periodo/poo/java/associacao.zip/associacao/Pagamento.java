package associacao;

public class Pagamento {

    Taxa taxa;
    private double valorPago;
    
    public Pagamento(Taxa taxa) {
        this.taxa = taxa;
        valorPago = 0;
    }

    public void pagarTaxa(double valor) {
        valorPago += valor;
    }

    public double getValorPago() {
        return valorPago;
    }

    public Taxa getTaxa() {
        return taxa;
    }



}
