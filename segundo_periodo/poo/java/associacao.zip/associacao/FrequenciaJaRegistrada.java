package associacao;

public class FrequenciaJaRegistrada extends Exception {
    public FrequenciaJaRegistrada(String msg) {
        super(msg);
    }
}
