package associacao;

public class AssociadoNaoExistente extends Exception{
    public AssociadoNaoExistente(String msg){
        super(msg);
    }
}
