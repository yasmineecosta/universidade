package associacao;

public class ValorInvalido extends Exception {
    public ValorInvalido(String msg) {
        super(msg);
    }
}
