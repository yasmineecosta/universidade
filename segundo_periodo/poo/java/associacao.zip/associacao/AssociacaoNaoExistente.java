package associacao;

public class AssociacaoNaoExistente extends Exception{
    public AssociacaoNaoExistente(String msg){
        super(msg);
    }
}

