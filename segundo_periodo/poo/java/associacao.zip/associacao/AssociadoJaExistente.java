package associacao;

public class AssociadoJaExistente extends Exception {
    public AssociadoJaExistente(String msg) {
        super(msg);
    }
}
